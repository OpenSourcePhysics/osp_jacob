(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DropTargetListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.7-v3');//Created 2020-01-18 17:07:45 Java2ScriptVisitor version 3.2.7-v3 net.sf.j2s.core.jar version 3.2.7-v3
