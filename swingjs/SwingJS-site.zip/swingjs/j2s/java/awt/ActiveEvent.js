(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ActiveEvent");
})();
;Clazz.setTVer('3.2.7-v3');//Created 2020-01-12 18:59:20 Java2ScriptVisitor version 3.2.7-v3 net.sf.j2s.core.jar version 3.2.7-v3
